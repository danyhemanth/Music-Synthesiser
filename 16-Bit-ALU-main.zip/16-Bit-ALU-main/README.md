# 16 bit Arithmetic Logic Unit

Directory structure will be <br>

<pre>
\-- ALU.vhd <br>
    \--Testbench_alu.vhd <br>
    \--KS16bit.vhd <br>
    \--Adder16bit.vhd <br>
    \--Sub16bit.vhd <br>
    \--xor16.vhd <br>
    \--nand16.vhd <br>
    \--sixteen_or.vhd <br>
    \--two_nand.vhd <br>
    \--two_or.vhd <br>
</pre>

# Contributors
1. Eeshaan Jain
2. Anupam Nayak
3. Vipin Singh
4. Sumeet Mishra
